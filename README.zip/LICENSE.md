MIT License

Copyright (c) 2025 A3H LLC

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the “Software”), to deal
in the Software for personal, educational, or internal business use, subject to
the following conditions:

- The above copyright notice and this permission notice shall be included in all
  copies or substantial portions of the Software.
- Commercial resale or redistribution is prohibited without explicit written
  permission from A3H LLC.

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND.
